/**
 * Created by Madhurjya on 6/21/2016.
 */
'use strict';
var isLocalEnv = false;
//var ip = "52.36.18.167";
var ip = "52.38.174.233";
serviceAdmin.factory('serviceRetailProfile', function ($resource,$http) {

});
