/**
 * Created by Madhurjya on 6/13/2016.
 */
'use strict';
angular.module('retail', ['bankModel','ngMaterial'])
  .controller('retailController',
    ['$scope',
      '$http',
      '$rootScope',
      '$timeout',
      '$mdSidenav',
      '$log',
      '$mdToast',
      'serviceAdminProfile',
      '$interval',
      '$mdDialog',
      function ($scope, $http, $rootScope, $timeout, $mdSidenav, $log, $mdToast, serviceAdminProfile,$interval,$mdDialog) {



        this.sampleAction = function(name, ev) {
          $mdDialog.show($mdDialog.alert()
            .title(name)
            .textContent('You triggered the "' + name + '" action')
            .ok('Great')
            .targetEvent(ev)
          );
        };


      //inline editable code
        $scope.model = {
          materialGroups: [{
            id: 1,
            name: "Ben",
            age: 28
          }, {
            id: 2,
            name: "Sally",
            age: 24
          }, {
            id: 3,
            name: "John",
            age: 32
          }, {
            id: 4,
            name: "Jane",
            age: 40
          }],
          selected: {}
        };
        $scope.addMaterialGroup = function(){
          $scope.model.materialGroups.unshift([]);

        }
        // gets the template to ng-include for a table row / item
        $scope.getTemplate = function (material) {
          if (material.id === $scope.model.selected.id) return 'edit';
          else return 'display';
        };

        $scope.editMaterialGroup = function (material) {
          $scope.model.selected = angular.copy(material);
        };

        $scope.saveMaterialGroup = function (idx) {
          console.log("Saving contact");
          $scope.model.materialGroups[idx] = angular.copy($scope.model.selected);
          $scope.reset();
        };

        $scope.reset = function () {
          $scope.model.selected = {};
        };



      }
    ])
